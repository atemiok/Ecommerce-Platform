"use client";
import {useState} from "react";

export default function InstagramImage({src,fallback,alt}:{src:string;fallback:string;alt:string}){
  const[failed,setFailed]=useState(false);
  return <img src={failed?fallback:src} alt={alt} loading="lazy" referrerPolicy="no-referrer" onError={()=>setFailed(true)}/>;
}
