"use client";

import Link from "next/link";
import {createContext,useContext,useEffect,useMemo,useState} from "react";
import {products} from "../lib/catalog";

type CartLine={slug:string;quantity:number};
type CartContextValue={items:CartLine[];count:number;open:boolean;ready:boolean;add:(slug:string)=>void;remove:(slug:string)=>void;setQuantity:(slug:string,quantity:number)=>void;clear:()=>void;show:()=>void;hide:()=>void};
const CartContext=createContext<CartContextValue|null>(null);
const money=(amount:number)=>new Intl.NumberFormat("en-KE",{style:"currency",currency:"KES",maximumFractionDigits:0}).format(amount);

export function CartProvider({children}:{children:React.ReactNode}){
  const[items,setItems]=useState<CartLine[]>([]);const[open,setOpen]=useState(false);const[ready,setReady]=useState(false);
  useEffect(()=>{const timer=window.setTimeout(()=>{try{const saved=JSON.parse(localStorage.getItem("ilonito-cart")||"[]") as CartLine[];setItems(saved.filter(line=>products.some(product=>product.slug===line.slug)&&line.quantity>0))}catch{}setReady(true)},0);return()=>window.clearTimeout(timer)},[]);
  useEffect(()=>{if(ready)localStorage.setItem("ilonito-cart",JSON.stringify(items))},[items,ready]);
  const value=useMemo<CartContextValue>(()=>({items,count:items.reduce((sum,line)=>sum+line.quantity,0),open,ready,add(slug){setItems(current=>{const found=current.find(line=>line.slug===slug);return found?current.map(line=>line.slug===slug?{...line,quantity:Math.min(9,line.quantity+1)}:line):[...current,{slug,quantity:1}]});setOpen(true)},remove(slug){setItems(current=>current.filter(line=>line.slug!==slug))},setQuantity(slug,quantity){setItems(current=>quantity<1?current.filter(line=>line.slug!==slug):current.map(line=>line.slug===slug?{...line,quantity:Math.min(9,quantity)}:line))},clear(){setItems([])},show(){setOpen(true)},hide(){setOpen(false)}}),[items,open,ready]);
  const lines=items.flatMap(line=>{const product=products.find(item=>item.slug===line.slug);return product?[{...line,product}]:[]});
  const subtotal=lines.reduce((sum,line)=>sum+line.product.priceKes*line.quantity,0);
  return <CartContext.Provider value={value}>{children}<aside className={`cart-drawer ${open?"open":""}`} aria-hidden={!open} aria-label="Shopping bag"><div className="cart-head"><div><p>Your bag</p><span>{value.count} {value.count===1?"piece":"pieces"}</span></div><button onClick={()=>setOpen(false)} aria-label="Close shopping bag">×</button></div>{lines.length?<><div className="cart-lines">{lines.map(({product,quantity})=><article key={product.slug}><img src={product.image} alt={product.name}/><div><span>{product.category}</span><h2>{product.name}</h2><strong>{money(product.priceKes)}</strong><div className="cart-quantity"><button onClick={()=>value.setQuantity(product.slug,quantity-1)} aria-label={`Remove one ${product.name}`}>−</button><span>{quantity}</span><button onClick={()=>value.setQuantity(product.slug,quantity+1)} aria-label={`Add one ${product.name}`}>+</button></div></div><button className="cart-remove" onClick={()=>value.remove(product.slug)}>Remove</button></article>)}</div><div className="cart-foot"><div><span>Subtotal</span><strong>{money(subtotal)}</strong></div><p>Delivery is arranged separately after payment.</p><Link href="/checkout" onClick={()=>setOpen(false)}>Checkout <span>→</span></Link><button onClick={()=>setOpen(false)}>Continue shopping</button></div></>:<div className="cart-empty"><p>Your bag is empty.</p><span>Choose a handcrafted piece to begin.</span><Link href="/shop" onClick={()=>setOpen(false)}>Explore the shop</Link></div>}</aside>{open&&<button className="cart-shade" onClick={()=>setOpen(false)} aria-label="Close shopping bag"/>}</CartContext.Provider>
}

export function useCart(){const value=useContext(CartContext);if(!value)throw new Error("useCart must be used inside CartProvider");return value}
