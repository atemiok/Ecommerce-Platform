import type { Metadata } from "next";
import "./globals.css";
import {CartProvider} from "./components/CartProvider";

export const metadata: Metadata = {
  title: "iLonito Designer Collections | Kenyan Luxury Leather",
  description: "Bold, timeless leather bags and accessories made in Kenya for those who value culture and intentional style.",
  openGraph: { title: "iLonito Designer Collections", description: "Kenyan luxury leather, crafted with culture and intent.", images: ["/og.png"] },
  twitter: { card: "summary_large_image", title: "iLonito Designer Collections", description: "Kenyan luxury leather, crafted with culture and intent.", images: ["/og.png"] },
  icons: { icon: "/favicon.svg", shortcut: "/favicon.svg" },
  other: { "codex-preview": "development" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><CartProvider>{children}</CartProvider></body></html>;
}
