import type {Metadata} from "next";
import SiteNav from "../components/SiteNav";import SiteFooter from "../components/SiteFooter";import ShopClient from "./ShopClient";
export const metadata:Metadata={title:"Shop | iLonito",description:"Explore handcrafted iLonito leather bags and accessories."};
export default function Shop(){return <main className="page-shell"><SiteNav/><section className="shop-hero"><h1>Shop</h1></section><ShopClient/><SiteFooter/></main>}
