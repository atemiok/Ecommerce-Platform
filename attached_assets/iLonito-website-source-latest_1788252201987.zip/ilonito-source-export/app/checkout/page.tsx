import type {Metadata} from "next";
import SiteNav from "../components/SiteNav";
import SiteFooter from "../components/SiteFooter";
import CheckoutClient from "./CheckoutClient";

export const metadata:Metadata={title:"Secure checkout | iLonito",description:"Pay securely for your iLonito leather piece with M-Pesa."};
export default function Checkout(){return <main className="page-shell"><SiteNav/><CheckoutClient/><SiteFooter/></main>}
