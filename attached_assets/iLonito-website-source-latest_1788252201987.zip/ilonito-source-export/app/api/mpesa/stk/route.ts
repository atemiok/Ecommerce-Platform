import {env} from "cloudflare:workers";
import {eq} from "drizzle-orm";
import {products} from "../../../lib/catalog";
import {getDb} from "../../../../db";
import {orders} from "../../../../db/schema";

export const runtime="edge";

type DarajaEnv={
  DARAJA_ENV?:string;DARAJA_CONSUMER_KEY?:string;DARAJA_CONSUMER_SECRET?:string;
  DARAJA_SHORTCODE?:string;DARAJA_PASSKEY?:string;DARAJA_TRANSACTION_TYPE?:string;
  DARAJA_CALLBACK_URL?:string;
};

const json=(body:unknown,status=200)=>Response.json(body,{status});
const normalizePhone=(value:string)=>{const digits=value.replace(/\D/g,"");if(/^0?7\d{8}$/.test(digits))return `254${digits.slice(-9)}`;if(/^2547\d{8}$/.test(digits))return digits;return null};
const timestamp=()=>{const parts=Object.fromEntries(new Intl.DateTimeFormat("en-GB",{timeZone:"Africa/Nairobi",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",second:"2-digit",hourCycle:"h23"}).formatToParts(new Date()).map(part=>[part.type,part.value]));return `${parts.year}${parts.month}${parts.day}${parts.hour}${parts.minute}${parts.second}`};
const resolveItems=(body:{items?:{slug?:string;quantity?:number}[];productSlug?:string})=>{const requested=body.items?.length?body.items:[{slug:body.productSlug,quantity:1}];return requested.flatMap(line=>{const product=products.find(item=>item.slug===line.slug);const quantity=Math.max(1,Math.min(9,Math.floor(Number(line.quantity)||1)));return product?[{product,quantity}]:[]})};

export async function POST(request:Request){
  try{
    const config=env as unknown as DarajaEnv;
    const body=await request.json() as {items?:{slug?:string;quantity?:number}[];productSlug?:string;phone?:string;name?:string;email?:string;address?:string};
    const items=resolveItems(body);const product=items[0]?.product;const amount=items.reduce((sum,line)=>sum+line.product.priceKes*line.quantity,0);const itemNames=items.map(line=>line.quantity>1?`${line.product.name} × ${line.quantity}`:line.product.name).join(", ");
    const phone=normalizePhone(body.phone||"");
    if(!product)return json({error:"Please choose a valid product."},400);
    if(!phone)return json({error:"Enter a valid Safaricom number, for example 0712 345 678."},400);
    if(!body.name?.trim()||!body.address?.trim())return json({error:"Enter your name and delivery address."},400);
    const required=[config.DARAJA_CONSUMER_KEY,config.DARAJA_CONSUMER_SECRET,config.DARAJA_SHORTCODE,config.DARAJA_PASSKEY];
    if(required.some(value=>!value))return json({error:"M-Pesa checkout is being activated. Please order through WhatsApp for now."},503);

    const base=config.DARAJA_ENV==="production"?"https://api.safaricom.co.ke":"https://sandbox.safaricom.co.ke";
    const auth=btoa(`${config.DARAJA_CONSUMER_KEY}:${config.DARAJA_CONSUMER_SECRET}`);
    const tokenResponse=await fetch(`${base}/oauth/v1/generate?grant_type=client_credentials`,{headers:{Authorization:`Basic ${auth}`}});
    if(!tokenResponse.ok)throw new Error("Daraja authentication failed");
    const tokenData=await tokenResponse.json() as {access_token?:string};
    if(!tokenData.access_token)throw new Error("Daraja did not return an access token");

    const now=timestamp();
    const orderId=crypto.randomUUID();
    const callback=config.DARAJA_CALLBACK_URL||`${new URL(request.url).origin}/api/mpesa/callback`;
    const db=getDb();
    await db.insert(orders).values({id:orderId,productSlug:product.slug,productName:itemNames,amountKes:amount,phone,customerName:body.name.trim(),email:body.email?.trim()||null,deliveryAddress:body.address.trim(),paymentMethod:"mpesa",status:"initiated",createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()});
    const stkResponse=await fetch(`${base}/mpesa/stkpush/v1/processrequest`,{method:"POST",headers:{Authorization:`Bearer ${tokenData.access_token}`,"Content-Type":"application/json"},body:JSON.stringify({
      BusinessShortCode:config.DARAJA_SHORTCODE,
      Password:btoa(`${config.DARAJA_SHORTCODE}${config.DARAJA_PASSKEY}${now}`),
      Timestamp:now,
      TransactionType:config.DARAJA_TRANSACTION_TYPE||"CustomerPayBillOnline",
      Amount:Math.max(1,Math.round(amount)),
      PartyA:phone,PartyB:config.DARAJA_SHORTCODE,PhoneNumber:phone,
      CallBackURL:callback,AccountReference:`ILONITO-${orderId.slice(0,8).toUpperCase()}`,
      TransactionDesc:`Payment for ${items.length} iLonito item${items.length===1?"":"s"}`
    })});
    const stk=await stkResponse.json() as {ResponseCode?:string;ResponseDescription?:string;CustomerMessage?:string;MerchantRequestID?:string;CheckoutRequestID?:string;errorMessage?:string};
    if(!stkResponse.ok||stk.ResponseCode!=="0"||!stk.CheckoutRequestID){
      await db.update(orders).set({status:"failed",resultDescription:stk.errorMessage||stk.ResponseDescription||"Could not start M-Pesa payment",updatedAt:new Date().toISOString()}).where(eq(orders.id,orderId));
      return json({error:stk.errorMessage||"M-Pesa could not start the payment. Please try again."},502);
    }
    await db.update(orders).set({status:"pending",merchantRequestId:stk.MerchantRequestID,checkoutRequestId:stk.CheckoutRequestID,updatedAt:new Date().toISOString()}).where(eq(orders.id,orderId));
    return json({orderId,message:stk.CustomerMessage||"Check your phone and enter your M-Pesa PIN."});
  }catch(error){
    console.error("M-Pesa STK error",error);
    return json({error:"We could not start M-Pesa payment. Please try again or use WhatsApp."},500);
  }
}
