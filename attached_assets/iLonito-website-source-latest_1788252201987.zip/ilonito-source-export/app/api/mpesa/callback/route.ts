import {eq} from "drizzle-orm";
import {getDb} from "../../../../db";
import {orders} from "../../../../db/schema";

export const runtime="edge";

type CallbackItem={Name?:string;Value?:string|number};
type DarajaCallback={Body?:{stkCallback?:{CheckoutRequestID?:string;ResultCode?:number;ResultDesc?:string;CallbackMetadata?:{Item?:CallbackItem[]}}}};

export async function POST(request:Request){
  try{
    const payload=await request.json() as DarajaCallback;
    const callback=payload.Body?.stkCallback;
    if(!callback?.CheckoutRequestID)return Response.json({ResultCode:0,ResultDesc:"Accepted"});
    const items=callback.CallbackMetadata?.Item||[];
    const receipt=items.find(item=>item.Name==="MpesaReceiptNumber")?.Value;
    await getDb().update(orders).set({
      status:callback.ResultCode===0?"paid":"failed",
      resultCode:callback.ResultCode,
      resultDescription:callback.ResultDesc||null,
      mpesaReceipt:receipt?String(receipt):null,
      updatedAt:new Date().toISOString(),
    }).where(eq(orders.checkoutRequestId,callback.CheckoutRequestID));
    return Response.json({ResultCode:0,ResultDesc:"Accepted"});
  }catch(error){
    console.error("M-Pesa callback error",error);
    return Response.json({ResultCode:0,ResultDesc:"Accepted"});
  }
}
