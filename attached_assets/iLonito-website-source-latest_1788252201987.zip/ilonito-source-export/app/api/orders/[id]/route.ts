import {eq} from "drizzle-orm";
import {getDb} from "../../../../db";
import {orders} from "../../../../db/schema";

export const runtime="edge";

export async function GET(_request:Request,{params}:{params:Promise<{id:string}>}){
  const{id}=await params;
  const order=await getDb().select({id:orders.id,status:orders.status,paymentMethod:orders.paymentMethod,productName:orders.productName,amountKes:orders.amountKes,mpesaReceipt:orders.mpesaReceipt,resultDescription:orders.resultDescription}).from(orders).where(eq(orders.id,id)).get();
  return order?Response.json(order):Response.json({error:"Order not found"},{status:404});
}
