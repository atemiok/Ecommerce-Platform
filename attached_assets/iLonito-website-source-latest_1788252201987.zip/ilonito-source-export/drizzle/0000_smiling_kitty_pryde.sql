CREATE TABLE `orders` (
	`id` text PRIMARY KEY NOT NULL,
	`product_slug` text NOT NULL,
	`product_name` text NOT NULL,
	`amount_kes` integer NOT NULL,
	`phone` text NOT NULL,
	`customer_name` text NOT NULL,
	`email` text,
	`delivery_address` text NOT NULL,
	`status` text DEFAULT 'initiated' NOT NULL,
	`merchant_request_id` text,
	`checkout_request_id` text,
	`mpesa_receipt` text,
	`result_code` integer,
	`result_description` text,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
