ALTER TABLE `orders` ADD `payment_method` text DEFAULT 'mpesa' NOT NULL;--> statement-breakpoint
ALTER TABLE `orders` ADD `provider_tracking_id` text;