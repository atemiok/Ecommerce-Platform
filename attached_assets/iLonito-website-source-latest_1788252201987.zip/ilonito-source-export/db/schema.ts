import {integer,sqliteTable,text} from "drizzle-orm/sqlite-core";

export const orders=sqliteTable("orders",{
  id:text("id").primaryKey(),
  productSlug:text("product_slug").notNull(),
  productName:text("product_name").notNull(),
  amountKes:integer("amount_kes").notNull(),
  phone:text("phone").notNull(),
  customerName:text("customer_name").notNull(),
  email:text("email"),
  deliveryAddress:text("delivery_address").notNull(),
  paymentMethod:text("payment_method").notNull().default("mpesa"),
  status:text("status").notNull().default("initiated"),
  merchantRequestId:text("merchant_request_id"),
  checkoutRequestId:text("checkout_request_id"),
  providerTrackingId:text("provider_tracking_id"),
  mpesaReceipt:text("mpesa_receipt"),
  resultCode:integer("result_code"),
  resultDescription:text("result_description"),
  createdAt:text("created_at").notNull(),
  updatedAt:text("updated_at").notNull(),
});
